create definer = root@localhost trigger placeorder
    after insert
    on orderlist
    for each row
BEGIN
UPDATE `paintings` SET status=0 WHERE `PaintingID`=new.PaintingID;
DELETE FROM `cart` WHERE PaintingID=new.PaintingID AND CustomerID=new.CustomerID;
END;

