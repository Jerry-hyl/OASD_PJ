create definer = root@localhost trigger deleteobject
    after delete
    on paintings
    for each row
    DELETE FROM `cart` WHERE PaintingID=old.PaintingID;

